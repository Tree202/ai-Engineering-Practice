# myshop —— 测试金字塔演示项目

一个迷你网上商店,用来演示测试金字塔的四层。配套教程见上级目录的
`index.html`(总入口)与 `ai-workflow/` 下的 23 页 HTML。

> 分支说明:最新内容(含网页层与 E2E)在 `docs/windows-readme` 分支;
> `main` 受质量门禁保护,须走 PR 过「三道检查」后合并 —— 门禁本身就是教程第 19 页的教具。

## 快速开始

```bash
# macOS / Linux(在本项目根目录执行)
.venv/bin/python -m pytest
```

```powershell
# Windows PowerShell(在本项目根目录执行;虚拟环境不存在时先 python -m venv .venv)
.\.venv\Scripts\python.exe -m pytest
```

应该看到:

- 没装 playwright:`17 passed, 1 skipped`(skip 的是 E2E,`importorskip` 生效)
- 装了 playwright + chromium:`19 passed`(两条 E2E 真跑,见文末)

## 三条常用命令

```bash
.venv/bin/python -m ruff check .     # 规范检查   0.02 秒
.venv/bin/python -m mypy             # 类型检查   0.27 秒
.venv/bin/python -m pytest           # 全量测试   3.66 秒(macOS 实测;Windows 约 4 秒)
```

> ⚠️ 一律用 `.venv/bin/python -m xxx` 的形式(Windows 对应 `.venv\Scripts\python.exe -m xxx`)。
> Claude Code 在 Bash 里跑命令不继承你终端的 `activate` 状态,写全路径才可靠。
> Windows 终端中文乱码时先执行 `$env:PYTHONUTF8="1"`。

## 目录结构

```
myshop/
├── .venv/                       虚拟环境(不进 git)
├── pyproject.toml               pytest + mypy + ruff 三合一配置
├── .gitignore
├── myshop/                      源代码
│   ├── __init__.py
│   ├── price.py                 纯函数,不碰任何外部东西
│   ├── order.py                 跨模块调用 + 写 sqlite
│   ├── api.py                   HTTP 接口(只用标准库)
│   └── web.py                   最小下单网页(给第 4 层 E2E 点的)
└── tests/
    ├── test_price.py            ① 单元测试   5 条   0.00 秒
    ├── test_order.py            ② 集成测试   5 条   0.02 秒
    ├── test_api.py              ③ 接口测试   7 条   3.64 秒
    └── e2e/
        ├── conftest.py          自动起停服务器 + 数据库隔离
        └── test_checkout_e2e.py ④ E2E   2 条(没装浏览器驱动时 skip)
```

## 分层跑(流程步骤 3 用局部,步骤 5a 用全量)

```bash
# 步骤 3:只跑改动相关的,快
.venv/bin/python -m pytest tests/test_price.py

# 步骤 5a:提交前跑全量,确认没弄坏别人
.venv/bin/python -m pytest
```

## 单独启动 API 试试

```bash
PYTHONPATH=. .venv/bin/python -m myshop.api
```

另开一个终端:

```bash
curl -X POST http://127.0.0.1:8000/orders \
  -H 'Content-Type: application/json' \
  -d '{"item":"咖啡","unit_cents":1250,"qty":2}'
```

应该返回:

```json
{"id": 1, "item": "咖啡", "qty": 2, "total_cents": 2500, "total_text": "¥25.00"}
```

## 练习:亲手确认测试真的有效

「一条从来不会红的测试,等于没有这条测试。」自己验证一下:

1. 把 `myshop/price.py` 里的 `{fen:02d}` 改成 `{fen}`(去掉补零)
2. 跑 `.venv/bin/python -m pytest tests/test_price.py` → 应该有 3 条变红
3. `git checkout -- .` 还原

更狠的一个:

1. 把 `order.py` 里 `total_text = format_price(total_cents)` 那一行挪到 `INSERT` **之后**
2. 再把 `if unit_cents < 0: raise ...` 删掉
3. 跑 `mypy` → **Success,它完全看不出来**
4. 跑 `pytest tests/test_order.py` → `test_单价为负数也要被拦下来并且不写库` 变红,
   而且失败原因是「库里查到了一条 -100 的脏数据」
5. `git checkout -- .` 还原

## E2E 想真跑的话

```bash
.venv/bin/python -m pip install pytest-playwright
.venv/bin/playwright install chromium
```

装完再跑 `pytest`,那条 skip 就变成两条真跑的 E2E:`web.py` 提供最小下单页面,
`tests/e2e/conftest.py` 会自动起停服务器并把订单写进临时数据库(不污染项目目录)。
